//
//  SwiftUIViewInterfazRegistro.swift
//  a
//
//  Created by CEDAM34 on 25/11/24.
//

import SwiftUI

struct LogInView: View {
    let colorBG: [Color] = [.black, .black.opacity(0.5)]
    let colorLetters: [Color] = [.init(red: 0.0, green: 1.0, blue: 1.0)]
    let colorLetters2: [Color] = [.init(red: 0.8, green: 0.8, blue: 0.0), .init(red: 0.0, green: 1.0, blue: 1.0)]
    let colorIcons: [Color] = [.init(red: 0.0, green: 1.0, blue: 1.0), .init(red: 0.8, green: 0.8, blue: 0.0)]
    
    @State var username: String
    @State var password: String
    
    var body: some View {
        ZStack{
            VStack(spacing: 25){
                Text("Inicio De Sesión")
                    .font(.largeTitle)
                    .foregroundStyle(colorLetters[0])
                    .padding(.horizontal, 20)
                
                Image(systemName: "house.fill")
                    .resizable()
                    .frame(width: 40, height: 40)
                    .padding()
                Spacer()
            }
            
            VStack {
                TextField("Username", text: $username, prompt: Text("Username")
                    .foregroundStyle(colorLetters2[0]))
                    .textFieldStyle(PlainTextFieldStyle())
                    .foregroundStyle(.black)
                    .padding()
                    .padding(.horizontal, 10)
                    .background(.clear)
                    .overlay{
                        RoundedRectangle(cornerRadius: 10)
                            .stroke(Color.black, lineWidth: 1)
                            .padding(.horizontal, 15)
                    }
                
                SecureField("Password", text: $password, prompt: Text("Password")
                    .foregroundStyle(colorLetters2[0]))
                    .textFieldStyle(PlainTextFieldStyle())
                    .foregroundStyle(.black)
                    .padding()
                    .padding(.horizontal, 6)
                    .background(.clear)
                    .overlay{
                        RoundedRectangle(cornerRadius: 10)
                            .stroke(Color.black, lineWidth: 1)
                            .padding(.horizontal, 15)
                    }
                
                Button(action: {}) {
                    ZStack {
                        Rectangle()
                            .frame(width: 250, height: 50)
                            .cornerRadius(15)
                            .foregroundStyle(colorIcons[0])
                        
                        Text("Iniciar Sesión")
                            .font(.title)
                            .foregroundStyle(Color.black)
                    }
                }
                .padding(.vertical, 6)
                .padding()
                
                Button(action:{}, label: {
                    Label{
                        Text("Iniciar sesión con Google")
                            .foregroundStyle(Color.black)
                            .padding()
                    }icon:{
                        Image(systemName: "house.fill")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 25, height: 25)
                            .foregroundColor(.black)
                            .padding(.leading, 10)
                    }.frame(width: 270, height: 50)
                        .background(colorIcons[0])
                        .clipShape(.rect(cornerRadius: 12))
                        .shadow(radius: 6)
                })
                
                Button(action:{}, label: {
                    Label{
                        Text("Iniciar sesión con Facebook")
                            .foregroundStyle(Color.black)
                            .padding()
                    }icon:{
                        Image(systemName: "facebook.fill")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 25, height: 25)
                            .foregroundColor(.black)
                            .padding(.leading, 10)
                    }.frame(width: 270, height: 50)
                        .background(colorIcons[0])
                        .clipShape(.rect(cornerRadius: 12))
                        .shadow(radius: 6)
                })
                
                
            }.padding(.horizontal,24)
        }
    }
}

#Preview {
    LogInView(username: "", password: "")
}
