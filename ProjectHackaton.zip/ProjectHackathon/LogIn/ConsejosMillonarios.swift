//
//  SwiftUIViewListasConsejos.swift
//  a
//
//  Created by CEDAM34 on 25/11/24.
//

import SwiftUI

struct ConsejosMillonarios: View {
    
    private let consejosList: [ConsejosItem] = [
        ConsejosItem(
          consejoPhto: "👾",
          name: "Descansar correctamente",
          description: "Seguir una rutina a la hora de irse a dormir, es decir, acostarse y levantarse a la misma hora todos los días e intentar descansar al menos 8 horas diarias."),
        ConsejosItem(
          consejoPhto: "🥑",
          name: "Avocado",
          description: "A pear-shaped avocado, sliced in half to show its yellow-green flesh and "
            + "large brown pit."),
        ConsejosItem(
          consejoPhto: "🍟",
          name: "French Fries",
          description: "Thin-cut, golden-brown French fries, served in a red carton, as at "
            + "McDonald’s."),
        ConsejosItem(
          consejoPhto: "🍕",
          name: "Pizza",
          description: "A slice of pepperoni pizza, topped with black olives on Google. WhatsApp "
            + "adds green pepper, Samsung white onion."),
        ConsejosItem(
          consejoPhto: "🧩",
          name: "Puzzle Piece",
          description: "Puzzle Piece was approved as part of Unicode 11.0 in 2018 under the name "
            + "“Jigsaw Puzzle Piece” and added to Emoji 11.0 in 2018."),
        ConsejosItem(
          consejoPhto: "🚀",
          name: "Rocket",
          description: "A rocket being propelled into space."),
        ConsejosItem(
          consejoPhto: "🗽",
          name: "Statue of Liberty",
          description: "The Statue of Liberty, often used as a depiction of New York City."),
        ConsejosItem(
          consejoPhto: "🧸",
          name: "Teddy Bear",
          description: "A classic teddy bear, as snuggled by a child when going to sleep."),
        ConsejosItem(
          consejoPhto: "🦄",
          name: "Unicorn",
          description: "The face of a unicorn, a mythical creature in the form of a white horse with "
            + "a single, long horn on its forehead."),
        ConsejosItem(
          consejoPhto: "👩🏽‍💻",
          name: "Woman Technologist",
          description: "A woman behind a computer screen, working in the field of technology."),
        ConsejosItem(
          consejoPhto: "🗺",
          name: "World Map",
          description: "A rectangular map of the world. Generally depicted as a paper map creased at "
            + "its folds, Earth’s surface shown in green on blue ocean."),
      ]
    
    var body: some View {
        NavigationView{
            List(consejosList){ consejosItem in
                NavigationLink(destination: DetailsView(consejosItem: consejosItem)){
                    HStack{
                        ConsejosCircleView(consejosItem: consejosItem)
                        Text(consejosItem.name)
                            .font(.headline)
                    }.padding(6)
                }
            }
            .navigationTitle("Consejos para cuidar la salud mental")
        }
    }
}

struct DetailsView: View {
    
    let consejosItem: ConsejosItem
    
    var body: some View {
        VStack{
            HStack{
                ConsejosCircleView(consejosItem: consejosItem)
                    .padding(.trailing, 5)
                
                Text(consejosItem.name)
                    .font(.largeTitle)
                    .bold()
                Spacer()
            }
            
            Text(consejosItem.description)
                .padding(.top)
            Spacer()
        }
        .padding()
        .navigationBarTitle(Text(consejosItem.name), displayMode: .inline)
    }
}

struct ConsejosCircleView: View {
    let consejosItem: ConsejosItem
    
    var body: some View {
        ZStack{
            Text(consejosItem.consejoPhto)
                .shadow(radius: 3)
                .font(.largeTitle)
                .frame(width: 65, height: 65)
                .overlay(Circle().stroke(Color.purple, lineWidth: 3))
        }
    }
}

struct ConsejosItem: Identifiable{
    let id = UUID()
    let consejoPhto: String
    let name: String
    let description: String
}

#Preview {
    ConsejosMillonarios()
}
