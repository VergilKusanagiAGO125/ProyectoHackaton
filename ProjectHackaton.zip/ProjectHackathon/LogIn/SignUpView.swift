//
//  SwiftUIViewRegistro.swift
//  a
//
//  Created by CEDAM34 on 25/11/24.
//

import SwiftUI

struct SignUpView: View {
    let colorBG: [Color] = [.black, .black.opacity(0.5)]
    let colorLetters: [Color] = [.init(red: 0.0, green: 1.0, blue: 1.0)]
    let colorLetters2: [Color] = [.init(red: 0.8, green: 0.8, blue: 0.0), .init(red: 0.0, green: 1.0, blue: 1.0)]
    let colorIcons: [Color] = [.init(red: 0.0, green: 1.0, blue: 1.0), .init(red: 0.8, green: 0.8, blue: 0.0)]
    
    @State var activarBoton = 0
    
    @State private var nombre = ""
    @State private var apellido1 = ""
    @State private var apellido2 = ""
    @State private var genero = ""
    @State private var edad = ""
    @State private var emailText = ""
    @State private var passwordText = ""
    @State private var confirmpasswordText = ""
    @State private var isValidEmail = true
    @State private var isValidPassword = true
    @State private var isConfirmValidPassword = true
    
    var body: some View {
        VStack {
            Text("Creacion De Cuenta")
                .font(.largeTitle)
                .foregroundStyle(colorLetters[0])
                .padding(.horizontal, 20)
            
            TextField("Nombre", text: $nombre, prompt: Text("Ingrese Nombre")
                .foregroundStyle(colorLetters2[0]))
            .textFieldStyle(PlainTextFieldStyle())
            .foregroundStyle(.black)
            .padding()
            .padding(.horizontal, 10)
            .background(.clear)
            .overlay{
                RoundedRectangle(cornerRadius: 10)
                    .stroke(Color.black, lineWidth: 1)
                    .padding(.horizontal, 15)
            }
            
            TextField("Apellido 1", text: $apellido1, prompt: Text("Ingrese Apellido 1")
                .foregroundStyle(colorLetters2[0]))
            .textFieldStyle(PlainTextFieldStyle())
            .foregroundStyle(.black)
            .padding()
            .padding(.horizontal, 10)
            .background(.clear)
            .overlay{
                RoundedRectangle(cornerRadius: 10)
                    .stroke(Color.black, lineWidth: 1)
                    .padding(.horizontal, 15)
            }
            
            TextField("Apellido 2", text: $apellido2, prompt: Text("Ingrese Apellido 2")
                .foregroundStyle(colorLetters2[0]))
            .textFieldStyle(PlainTextFieldStyle())
            .foregroundStyle(.black)
            .padding()
            .padding(.horizontal, 10)
            .background(.clear)
            .overlay{
                RoundedRectangle(cornerRadius: 10)
                    .stroke(Color.black, lineWidth: 1)
                    .padding(.horizontal, 15)
            }
            
            TextField("Edad", text: $edad, prompt: Text("Ingrese Edad")
                .foregroundStyle(colorLetters2[0]))
            .textFieldStyle(PlainTextFieldStyle())
            .foregroundStyle(.black)
            .padding()
            .padding(.horizontal, 10)
            .background(.clear)
            .overlay{
                RoundedRectangle(cornerRadius: 10)
                    .stroke(Color.black, lineWidth: 1)
                    .padding(.horizontal, 15)
            }
            
            TextField("Email", text: $emailText, prompt: Text("Ingrese Email")
                .foregroundStyle(colorLetters2[0]))
            .textFieldStyle(PlainTextFieldStyle())
            .foregroundStyle(.black)
            .padding()
            .padding(.horizontal, 10)
            .background(.clear)
            .overlay{
                RoundedRectangle(cornerRadius: 10)
                    .stroke(Color.black, lineWidth: 1)
                    .padding(.horizontal, 15)
            }
            SecureField("passwordText", text: $passwordText, prompt: Text("Ingrese Contraseña")
                .foregroundStyle(colorLetters2[0]))
                .textFieldStyle(PlainTextFieldStyle())
                .foregroundStyle(.black)
                .padding()
                .padding(.horizontal, 6)
                .background(.clear)
                .overlay{
                    RoundedRectangle(cornerRadius: 10)
                        .stroke(Color.black, lineWidth: 1)
                        .padding(.horizontal, 15)
                }
            SecureField("Confirrmar contraseña", text: $confirmpasswordText, prompt: Text("Confirmar contraseña")
                .foregroundStyle(colorLetters2[0]))
                .textFieldStyle(PlainTextFieldStyle())
                .foregroundStyle(.black)
                .padding()
                .padding(.horizontal, 6)
                .background(.clear)
                .overlay{
                    RoundedRectangle(cornerRadius: 10)
                        .stroke(Color.black, lineWidth: 1)
                        .padding(.horizontal, 15)
                }
            
            if(nombre.isEmpty || apellido1.isEmpty || apellido2.isEmpty || edad.isEmpty || emailText.isEmpty || passwordText.isEmpty || confirmpasswordText.isEmpty) {
                
            }
            else {
                if(passwordText == confirmpasswordText){
                    Text("Datos correctos")
                    Button(action: {}) {
                        ZStack {
                            Rectangle()
                                .frame(width: 250, height: 50)
                                .cornerRadius(15)
                            
                            Text("Iniciar Sesión")
                                .font(.title)
                                .foregroundStyle(Color.white)
                        }
                    }
                }else{
                    Text("Datos erroneos")
                }
            }
        }
    }
}

#Preview {
    SignUpView()
}

