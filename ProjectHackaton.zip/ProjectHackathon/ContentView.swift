//
//  ContentView.swift
//  ProjectHackathon
//
//  Created by CEDAM33 on 25/11/24.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack {
            
        }
    }
}

#Preview {
    ContentView()
}
