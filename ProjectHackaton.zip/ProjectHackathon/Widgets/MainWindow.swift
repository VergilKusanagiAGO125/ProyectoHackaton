//
//  MainWindow.swift
//  ProjectHackathon
//
//  Created by CEDAM33 on 25/11/24.
//

import SwiftUI

struct MainWindow: View {
    let colorBG: [Color] = [.black, .black.opacity(0.5)]
    let colorLetters: [Color] = [.init(red: 0.0, green: 1.0, blue: 1.0)]
    let colorLetters2: [Color] = [.init(red: 0.8, green: 0.8, blue: 0.0), .init(red: 0.0, green: 1.0, blue: 1.0)]
    let colorIcons: [Color] = [.init(red: 0.0, green: 1.0, blue: 1.0), .init(red: 0.8, green: 0.8, blue: 0.0)]
    
    var body: some View {
        ZStack {
            LinearGradient(colors: colorBG, startPoint: .bottomLeading, endPoint: .topLeading).ignoresSafeArea()
            VStack {
                NavigatorView(index: 1)
            }
        }
    }
}

#Preview {
    MainWindow()
}
