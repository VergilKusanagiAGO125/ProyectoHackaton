//
//  NavigatorView.swift
//  ProjectHackathon
//
//  Created by CEDAM33 on 25/11/24.
//

import SwiftUI

struct NavigatorView: View {
    let colorBG: [Color] = [.black, .black.opacity(0.5)]
    let colorLetters: [Color] = [.init(red: 0.0, green: 1.0, blue: 1.0)]
    let colorLetters2: [Color] = [.init(red: 0.8, green: 0.8, blue: 0.0), .init(red: 0.0, green: 1.0, blue: 1.0)]
    let colorIcons: [Color] = [.init(red: 0.0, green: 1.0, blue: 1.0), .init(red: 0.8, green: 0.8, blue: 0.0)]
    
    let lstStructPanel: [StructPanel] = [
        StructPanel(idPanel: 1, titulo: "Consejos", icono: "accessibility.fill"),
        StructPanel(idPanel: 2, titulo: "Menu Principal", icono: "house.fill"),
        StructPanel(idPanel: 3, titulo: "Especialistas En Salud Mental", icono: "message.fill")
    ]
    
    @State var index:Int
    
    var body: some View {
        VStack {
            HStack {
                Button(action: {
                        self.index = 3
                    }) {
                        ZStack {
                            Rectangle()
                                .frame(width: 160,height: 40)
                                .cornerRadius(10)
                                .foregroundStyle(self.index == 3 ? colorIcons[0]: colorIcons[1])
                            Text("Crear Cuenta")
                                .foregroundStyle(self.index == 3 ? colorLetters2[0]: colorLetters2[1])
                        }
                    }
                    .padding(10)
                Button(action: {
                        self.index = 4
                    }) {
                        ZStack {
                            Rectangle()
                                .frame(width: 160,height: 40)
                                .cornerRadius(10)
                                .foregroundStyle(self.index == 4 ? colorIcons[0]: colorIcons[1])
                            Text("Iniciar Sesión")
                                .foregroundStyle(self.index == 4 ? colorLetters2[0]: colorLetters2[1])
                        }
                    }
                    .padding(10)
            }
            
            if(self.index == 0) {
                ConsejosMillonarios()
            }
            else if(self.index == 1) {
                PanelView2(strpanel: lstStructPanel[1])
            }
            else if(self.index == 2) {
                PanelView3(strpanel: lstStructPanel[2])
            }
            else if(self.index == 3) {
                SignUpView()
            }
            else if(self.index == 4) {
                LogInView(username: "", password: "")
            }
            Spacer()
            HStack {
                Button(action: {
                        self.index = 0
                    }) {
                        Image(systemName: "\(lstStructPanel[0].icono)")
                            .resizable()
                            .frame(width: 50, height: 50)
                            .foregroundStyle(self.index == 0 ? colorIcons[0]: colorIcons[1])
                    }
                    .padding(10)
                Button(action: {
                        self.index = 1
                    }) {
                        Image(systemName: "\(lstStructPanel[1].icono)")
                            .resizable()
                            .frame(width: 50, height: 50)
                            .foregroundStyle(self.index == 1 ? colorIcons[0]: colorIcons[1])
                    }
                    .padding(10)
                Button(action: {
                        self.index = 2
                    }) {
                        Image(systemName: "\(lstStructPanel[2].icono)")
                            .resizable()
                            .frame(width: 50, height: 50)
                            .foregroundStyle(self.index == 2 ? colorIcons[0]: colorIcons[1])
                    }
                    .padding(10)
            }
            .padding()
            .padding(.horizontal)
        }
    }
}

#Preview {
    NavigatorView(index: 1)
}
