//
//  StructsList.swift
//  ProjectHackathon
//
//  Created by CEDAM33 on 25/11/24.
//

import SwiftUI

class User {
    var nombre: String
    var apellido_1: String
    var apellido_2: String
    var fechaNacimiento: Date
    var password: String
    
    init(nombre: String, apellido_1: String, apellido_2: String, fechaNacimiento: Date, password: String) {
        self.nombre = nombre
        self.apellido_1 = apellido_1
        self.apellido_2 = apellido_2
        self.fechaNacimiento = fechaNacimiento
        self.password = password
    }
    
    public var readNombre: String {
        get {
            return nombre
        }
        set(newNombre) {
            nombre = newNombre
        }
    }
    
    public var readApellido_1: String {
        get {
            return apellido_1
        }
        set(newApellido_1) {
            apellido_1 = newApellido_1
        }
    }
    
    public var readApellido_2: String {
        get {
            return apellido_2
        }
        set(newApellido_2) {
            apellido_2 = newApellido_2
        }
    }
    
    public var readFechaNacimiento: Date {
        get {
            return fechaNacimiento
        }
        set(newFechaNacimiento) {
            fechaNacimiento = newFechaNacimiento
        }
    }
    
    public var readPassword: String {
        get {
            return password
        }
        set(newPassword) {
            password = newPassword
        }
    }
}

struct StructUser: Identifiable {
    var id = UUID()
    var user: User
}

struct StructPanel: Identifiable {
    var id = UUID()
    var idPanel: Int
    var titulo: String
    var icono: String
}

struct obtDate {
    func FormatearFecha(dateString: String) -> Date {
        let format = DateFormatter()
        format.dateFormat = "dd/MM/yyyy"
        
        if let fechaAct = format.date(from: dateString) {
            return fechaAct
        } else {
            return Date()
        }
        
    }
    
    func ObtenerEdad(dateString: String) -> Int {
        return 18
    }
}
