//
//  ListPanelView.swift
//  ProjectHackathon
//
//  Created by CEDAM33 on 25/11/24.
//

import SwiftUI

struct PanelView1: View {
    let colorBG: [Color] = [.black, .black.opacity(0.5)]
    let colorLetters: [Color] = [.init(red: 0.0, green: 1.0, blue: 1.0)]
    let colorLetters2: [Color] = [.init(red: 0.8, green: 0.8, blue: 0.0), .init(red: 0.0, green: 1.0, blue: 1.0)]
    let colorIcons: [Color] = [.init(red: 0.0, green: 1.0, blue: 1.0), .init(red: 0.8, green: 0.8, blue: 0.0)]
    
    var strpanel: StructPanel
    
    var body: some View {
        ZStack {
            VStack(alignment: .leading) {
                HStack {
                    Text("\(strpanel.titulo)")
                        .font(.largeTitle)
                        .foregroundStyle(colorLetters[0])
                        .padding(.horizontal, 20)
                    Spacer()
                }
                Spacer()
            }
            
        }
    }
}

struct PanelView2: View {
    let colorBG: [Color] = [.black, .black.opacity(0.5)]
    let colorLetters: [Color] = [.init(red: 0.0, green: 1.0, blue: 1.0)]
    let colorIcons: [Color] = [.init(red: 0.0, green: 1.0, blue: 1.0)]
    
    var strpanel: StructPanel
    
    var body: some View {
        ZStack {
            VStack(alignment: .leading) {
                HStack {
                    Text("\(strpanel.titulo)")
                        .font(.largeTitle)
                        .foregroundStyle(colorLetters[0])
                        .padding(.horizontal, 20)
                    Spacer()
                }
                Spacer()
            }
            
        }
    }
}

struct PanelView3: View {
    let lstcontactos: [StructUser] = [
        StructUser(user: User(nombre: "Us1", apellido_1: "Ap1", apellido_2: "Ap2", fechaNacimiento: Date(), password: "1234")),
        StructUser(user: User(nombre: "Us2", apellido_1: "Ap1", apellido_2: "Ap2", fechaNacimiento: Date(), password: "1234")),
        StructUser(user: User(nombre: "Us3", apellido_1: "Ap1", apellido_2: "Ap2", fechaNacimiento: Date(), password: "1234"))
    ]
    
    let colorBG: [Color] = [.black, .black.opacity(0.5)]
    let colorLetters: [Color] = [.init(red: 0.0, green: 1.0, blue: 1.0)]
    let colorIcons: [Color] = [.init(red: 0.0, green: 1.0, blue: 1.0)]
    
    var strpanel: StructPanel
    
    var body: some View {
        ZStack {
            VStack {
                HStack {
                    Text("\(strpanel.titulo)")
                        .font(.largeTitle)
                        .foregroundStyle(colorLetters[0])
                        .padding(.horizontal, 20)
                    Spacer()
                }
                Spacer()
                NavigationView {
                    List(lstcontactos) { index in NavigationLink(destination: ContactDetailPreview(myUser: index.user)) {
                            ContactView(myUser: index.user)
                        }
                    }
                    .listRowSeparator(.hidden)
                }
            }
        }
    }
}

#Preview {
    PanelView3(strpanel: StructPanel(idPanel: 1, titulo: "Panel De Ejemplo", icono: "house.fill"))
}
