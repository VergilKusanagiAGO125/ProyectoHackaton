//
//  ContactDetailPreview.swift
//  ProjectHackathon
//
//  Created by CEDAM33 on 25/11/24.
//

import SwiftUI

struct ContactDetailPreview: View {
    let colorBG: [Color] = [.black, .black.opacity(0.5)]
    let colorLetters: [Color] = [.init(red: 0.0, green: 1.0, blue: 1.0)]
    let colorLetters2: [Color] = [.init(red: 0.8, green: 0.8, blue: 0.0), .init(red: 0.0, green: 1.0, blue: 1.0)]
    let colorIcons: [Color] = [.init(red: 0.0, green: 1.0, blue: 1.0), .init(red: 0.8, green: 0.8, blue: 0.0)]
    
    let edad = obtDate()
    
    var myUser = User(nombre: "Ariel", apellido_1: "Gonzalez", apellido_2: "Ordaz", fechaNacimiento: obtDate().FormatearFecha(dateString: "28/01/2001"), password: "1234")
    
    var body: some View {
        VStack {
            Image(systemName: "person.fill")
                .resizable()
                .frame(width: 160, height: 160)
            Text("\(myUser.nombre) \(myUser.apellido_1) \(myUser.apellido_2)")
                .font(.title2)
            HStack (alignment: .bottom) {
                Text("Edad: ")
                    .font(.title2)
                    .padding(.horizontal, 20)
                Spacer()
                ZStack {
                    Rectangle()
                        .frame(height: 30)
                        .cornerRadius(10)
                        .padding(.horizontal, 20)
                        .offset(y: 20)
                    Text("\(myUser.readFechaNacimiento)")
                        .font(.title3)
                        .padding(.horizontal, 20)
                        .foregroundStyle(.white)
                        .offset(y: 20)
                }
            }
            HStack (alignment: .bottom) {
                Text("Edad: ")
                    .font(.title2)
                    .padding(.horizontal, 20)
                Spacer()
                ZStack {
                    Rectangle()
                        .frame(height: 30)
                        .cornerRadius(10)
                        .padding(.horizontal, 20)
                        .offset(y: 20)
                    Text("\(myUser.readFechaNacimiento)")
                        .font(.title3)
                        .padding(.horizontal, 20)
                        .foregroundStyle(.white)
                        .offset(y: 20)
                }
            }
        }
    }
}

#Preview {
    ContactDetailPreview()
}
